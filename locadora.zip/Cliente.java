package locadora;

public class Cliente {
    //ATRIBUTES
    private int codigo, cpf, idade, qtdFilmesAlugados;
    private String nome;
    //CONSTRUCTOR
    Cliente(int codigo, String nome, int cpf){
        setCodigo(codigo);
        setNome(nome);
        setCpf(cpf);
        this.qtdFilmesAlugados = 0;
    }
    //METHODS
    //GETTERS & SETTERS
    int getCodigo() {
        return codigo;
    }

    void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    int getCpf() {
        return cpf;
    }

    void setCpf(int cpf) {
        this.cpf = cpf;
    }

    int getIdade() {
        return idade;
    }

    void setIdade(int idade) {
        this.idade = idade;
    }

    String getNome() {
        return nome;
    }

    void setNome(String nome) {
        this.nome = nome;
    }

    int getQtdFilmesAlugados() {
        return qtdFilmesAlugados;
    }

    void setQtdFilmesAlugados(int qtdFilmesAlugados) {
        this.qtdFilmesAlugados = qtdFilmesAlugados;
    }
}
