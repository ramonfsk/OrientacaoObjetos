package locadora;

public class Funcionario {
    //ATRIBUTES
    private int codigo, cpf, idade;
    private String nome;
    //CONSTRUCTOR
    Funcionario(int codigo, String nome, int cpf){
        setCodigo(codigo);
        setNome(nome);
        setCpf(cpf);
    }
    //METHOD
    //GETTERS & SETTERS
    int getCodigo() {
        return codigo;
    }

    void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    int getCpf() {
        return cpf;
    }

    void setCpf(int cpf) {
        this.cpf = cpf;
    }

    String getNome() {
        return nome;
    }

    void setNome(String nome) {
        this.nome = nome;
    } 
}
