package locadora;

public class Filme {
    //ATRIBUTES
    private int codigo;
    private String autor, titulo;
    //CONSTRUCTOR
    Filme(){};
    Filme(int codigo, String autor, String titulo){
        setCodigo(codigo);
        setAutor(autor);
        setTitulo(titulo);
    }
    //METHODS
    //GETTERS & SETTERS
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
}
