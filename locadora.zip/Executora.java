package locadora;

public class Executora {
    public static void main(String[] args){
        Funcionario func1 = new Funcionario(321, "Elon Musk", 555333);
        Funcionario func2 = new Funcionario(547, "Steve Rogers", 999888);
        Funcionario func3 = new Funcionario(741, "Clemilton", 8745333);
        Funcionario func4 = new Funcionario(787, "Raphael", 895333);
        Funcionario func5 = new Funcionario(555, "Kaka", 222222);
        Funcionario func6 = new Funcionario(845, "Shevchencko", 333333);
        
        Filme flm1 = new Filme(111, "Ridley Scott", "Prometheus");
        Filme flm2 = new Filme(222, "Denis Villeneuve", "Blade Runner 2049");
        Filme flm3 = new Filme(333, "Ridley Scott", "Black Hawk Down");
        Filme flm4 = new Filme(551, "Peter Jackson", "The Lord of The Rings: The Fellowship of the Ring");
        Filme flm5 = new Filme(552, "Peter Jackson", "The Lord of The Rings: The Two Towers");
        Filme flm6 = new Filme(553, "Peter Jackson", "The Lord of The Rings: Return of the King");
        Filme flm7 = new Filme(441, "Sisters Wachowski", "The Matrix");
        Filme flm8 = new Filme(442, "Sisters Wachowski", "The Matrix: Reloaded");
        Filme flm9 = new Filme(441, "Sisters Wachowski", "The Matrix: Revolutions");
        Filme flm10 = new Filme(777, "David Fincher", "Figth Club");
        
        Cliente clt1 = new Cliente(123, "Ramon Ferreira", 999999);
        Cliente clt2 = new Cliente(463, "Julia GAM", 777777);
        
        Filial fil1 = new Filial(666, "Baphomet Store");
        if(fil1.addFuncionario(func1));
        if(fil1.addFuncionario(func2));
        if(fil1.addFilme(flm1));
        if(fil1.addFilme(flm2));
        if(fil1.addFilme(flm3));
        if(fil1.addFilme(flm10));
        if(fil1.addCliente(clt1));
        if(fil1.addCliente(clt2));
        
        Filial fil2 = new Filial(999, "Skyies Locadora");
        if(fil2.addFuncionario(func3));
        if(fil2.addFuncionario(func4));
        if(fil2.addFilme(flm4));
        if(fil2.addFilme(flm5));
        if(fil2.addFilme(flm6));
        if(fil2.addCliente(clt1));
        if(fil2.addCliente(clt2));
        
        Filial fil3 = new Filial(444, "FFVII LocalStore");
        if(fil3.addFuncionario(func5));
        if(fil3.addFuncionario(func6));
        if(fil3.addFilme(flm1));
        if(fil3.addFilme(flm3));
        if(fil3.addFilme(flm7));
        if(fil3.addFilme(flm8));
        if(fil3.addFilme(flm9));
        if(fil3.addCliente(clt1));
        if(fil3.addCliente(clt2));
        
        fil1.locarFilme(20190325, clt1, func5, flm9);
        fil1.locarFilme(20190325, clt2, func6, flm5);
        fil1.locarFilme(20190325, clt2, func4, flm10);
        fil1.locarFilme(20190325, clt1, func1, flm8);
        fil1.locarFilme(20190325, clt1, func1, flm6);
        
        for (Locacao locacoes : fil1.getLocacoes()) {
            System.out.printf("Data: %d | Cliente: %s | Filme: %s | Func: %s\n",
                locacoes.getData(), 
                locacoes.getCliente().getNome(), 
                locacoes.getFilme().getTitulo(), 
                locacoes.getFuncionario().getNome()
            );
        }
        
        for (Locacao locacoes : fil2.getLocacoes()) {
            System.out.printf("Data: %d | Cliente: %s | Filme: %s | Func: %s\n",
                locacoes.getData(), 
                locacoes.getCliente().getNome(), 
                locacoes.getFilme().getTitulo(), 
                locacoes.getFuncionario().getNome()
            );
        }
        
        for (Locacao locacoes : fil3.getLocacoes()) {
            System.out.printf("Data: %d | Cliente: %s | Filme: %s | Func: %s\n",
                locacoes.getData(), 
                locacoes.getCliente().getNome(), 
                locacoes.getFilme().getTitulo(), 
                locacoes.getFuncionario().getNome()
            );
        }
    }
}
