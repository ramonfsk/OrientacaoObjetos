package locadora;

public class Locacao {
    //ATRIBUTES
    private int data;
    private Cliente cliente;
    private Funcionario funcionario;
    private Filme filme;
    //CONSTRUCTOR
    Locacao(int data, Cliente cliente, Funcionario funcionario, Filme filme){
        setData(data);
        setCliente(cliente);
        setFuncionario(funcionario);
        setFilme(filme);
    }
    //METHODS
    //GETTERS & SETTERS
    int getData() {
        return data;
    }

    void setData(int data) {
        this.data = data;
    }

    Cliente getCliente() {
        return cliente;
    }

    void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    Funcionario getFuncionario() {
        return funcionario;
    }

    void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    Filme getFilme() {
        return filme;
    }

    void setFilme(Filme filme) {
        this.filme = filme;
    } 
}
