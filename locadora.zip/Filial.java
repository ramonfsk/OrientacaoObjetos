package locadora;
import java.util.ArrayList;

public class Filial {
    //ATRIBUTES
    private int cnpj, qtdFuncionarios;
    private String nome;
    private ArrayList<Cliente> clientes = new ArrayList<Cliente>();
    private ArrayList<Filme> filmes = new ArrayList<Filme>();
    private ArrayList<Funcionario> funcionarios = new ArrayList<Funcionario>();
    private ArrayList<Locacao> locacoes = new ArrayList<Locacao>();
    //CONSTRUCTOR
    Filial(int cnpj, String nome){
        setCnpj(cnpj);
        setNome(nome);
        this.qtdFuncionarios = 0;
    }
    //METHODS
    boolean addFuncionario(Funcionario func){
        if(qtdFuncionarios > 2){
            System.out.printf("Limite de funcionarios atingido!\n");
            return false;
        }
        funcionarios.add(func);
        setQtdFuncionarios(qtdFuncionarios += 1);
        return true;
    }
    
    boolean removeFuncionario(Funcionario func){
        if(qtdFuncionarios <= 0){
            System.out.printf("Nao ha funcionarios para serem removidos!\n");
            return false;
        }
        setQtdFuncionarios(qtdFuncionarios -= 1);
        funcionarios.remove(func);
        return true;
    }
    
    boolean addFilme(Filme flm){
        if(flm.getCodigo() < 0 && flm.getCodigo() > 999){
            System.out.println("Codigo invalido!");
            return false;
        }
        if(flm.getAutor().isEmpty() && flm.getTitulo().isEmpty()){
            System.out.println("O autor e nome nao podem ser vazios!");
            return false;
        }
        filmes.add(flm);
        return true;
    }
    
    boolean remFilme(Filme flm){
        if(filmes.isEmpty()){
            System.out.println("Nao ha filmes para remover!");
            return false;
        }
        filmes.remove(flm);
        return true;
    }
    
    boolean addCliente(Cliente clt){
        if(clt.getCodigo() < 0 && clt.getCodigo() > 999){
            System.out.println("Codigo invalido!");
            return false;
        }
        
        if(clt.getNome().isEmpty()){
            System.out.println("Nome invalido!");
            return false;
        }

        if(clt.getCpf() < 0 && clt.getCpf() > 999999){
            System.out.println("Cpf invalido!");
            return false;
        }
        clientes.add(clt);
        return true;
    }
    
    boolean remCliente(Cliente clt){
        if(clientes.isEmpty()){
            System.out.println("Nao ha clientes para remover!");
            return false;
        }
        clientes.remove(clt);
        return true;       
    }
    
    boolean locarFilme(int data, Cliente clt, Funcionario func, Filme flm){
        if(clt.getQtdFilmesAlugados() >= 2){
            System.out.printf("Limite de filmes atingidos para o cliente %s!\n", clt.getNome());
            return false;
        }
        Locacao tmpLocacao = new Locacao(data, clt, func, flm);
        locacoes.add(tmpLocacao);
        clt.setQtdFilmesAlugados(clt.getQtdFilmesAlugados() + 1);
        System.out.println(clt.getQtdFilmesAlugados());
        return true;
    }
    //GETTERS & SETTERS
    int getCnpj() {
        return cnpj;
    }

    void setCnpj(int cnpj) {
        this.cnpj = cnpj;
    }

    int getQtdFuncionarios() {
        return qtdFuncionarios;
    }

    void setQtdFuncionarios(int qtdFuncionarios) {
        this.qtdFuncionarios = qtdFuncionarios;
    }

    String getNome() {
        return nome;
    }

    void setNome(String nome) {
        this.nome = nome;
    }

    ArrayList<Funcionario> getFuncionarios() {
        return funcionarios;
    }
    
    ArrayList<Locacao> getLocacoes() {
        return locacoes;
    }
    
    ArrayList<Filme> getFilmes() {
        return filmes;
    }
}
