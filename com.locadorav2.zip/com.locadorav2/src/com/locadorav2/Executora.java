package com.locadorav2;

import java.util.ArrayList;

public class Executora {
	public static void main(String[] args) {
		ArrayList<Filme> flms = new ArrayList<Filme>();
		ArrayList<Cliente> clnts = new ArrayList<Cliente>();
		ArrayList<Funcionario> funcs = new ArrayList<Funcionario>();
		ArrayList<Locacao> locs = new ArrayList<Locacao>();
		ArrayList<Filial> flais = new ArrayList<Filial>();
		
		int opcao = 0;
		do {
			opcao = View.solicitarDadosInt("Escolha uma opcao: ",
					"1 - Filmes\n"
					+"2 - Clientes\n"
					+"3 - Funcionarios\n"
					+"4 - Locacoes\n"
					+"0 - Sair.."
			);
			switch (opcao) {
			case 0:
				opcao = 0;
				break;
			case 1:
				break;
			case 2:
				break;
			case 3:
				break;
			case 4:
				try {
					if(!flms.isEmpty() || !clnts.isEmpty() || !funcs.isEmpty())
						
				} catch (Exception e) {
					View.exibirMsgErro(e.getMessage());
				}
				break;
			default:
				View.exibirMsgErro("Opcao invalida!");
				break;
			}
		} while (opcao != 0);
	}
	
	public static void subMenuFilmes() {
		
	}
	
	public static void subMenuPessoas() {
		
	}
	
	public static void subMenuLocacoes() {
		
	}
	
	public static void subMenuFiliais() {
		
	}
}
