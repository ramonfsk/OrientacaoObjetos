package com.locadorav2;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Locacao {
	//ATTRIBUTES
	private Cliente clnt;
	private Funcionario func;
	private ArrayList<Filme> filmes = new ArrayList<Filme>();
	private String strDataHora;
	private static Date date = new Date();
	private static DateFormat dateFormat = new SimpleDateFormat("dd-mm-yyyy hh:mm");
	//CONSTRUCTOR
	public Locacao(Cliente clnt, Funcionario func) {
		setClnt(clnt);
		setFunc(func);
		strDataHora = dateFormat.format(date);
	}
	//METHODS
	public void addFilme(Filme flm) {
		this.filmes.add(flm);
	}
	public void remFilme(int index) {
		this.filmes.remove(index);
	}
	//GETTERS & SETTERS
	public Cliente getClnt() {
		return clnt;
	}
	public void setClnt(Cliente clnt) {
		this.clnt = clnt;
	}
	public Funcionario getFunc() {
		return func;
	}
	public void setFunc(Funcionario func) {
		this.func = func;
	}
	public String getDataHora() {
		return strDataHora;
	}
	public ArrayList<Filme> getFilmes() {
		return filmes;
	}
}
