package com.locadorav2;

import java.util.ArrayList;

public class Utils {

	public static Filme addFilme() {
		Filme tmp = new Filme(
				View.solicitarDadosInt("Filme", "Informe o codigo do filme: "), 
				View.solicitarDadosString("Filme", "Agora, informe o titulo do filme: "), 
				View.solicitarDadosString("Filme", "E por ultimo, informe o diretor: ")
		);
		
		return tmp;
	}
	
	public static Funcionario addFunc() {
		Funcionario tmp = new Funcionario(
				View.solicitarDadosInt("Funcionario", "Informe um codigo para o funcionario: "),
				View.solicitarDadosString("Funcionario", "Agora informe o nome: "),
				View.solicitarDadosString("Funcionario", "E por ultimo informe o telefone: ")
		);
		
		return tmp;
	}
	
	public static Cliente addClnt() {
		Cliente tmp = new Cliente(
				View.solicitarDadosInt("Cliente", "Informe um codigo para o cliente: "),
				View.solicitarDadosString("Cliente", "Agora informe o nome: "),
				View.solicitarDadosString("Cliente", "E por ultimo informe o telefone: ")
		);
		
		return tmp;
	}
	
	public static Locacao addLocacao(ArrayList<Filme> flms, ArrayList<Cliente> clnts, ArrayList<Funcionario> funcs) {
		Locacao tmp = new Locacao(
				Utils.selecionaIndexFilme(flms),
				
		);
		
		return tmp;
	}
	
	public static Filme selecionaIndexFilme(ArrayList<Filme> flms) {
		int index;
		String strOpcoes = null;
		Filme tmp;
		
		for (Filme filme : flms)
			strOpcoes = strOpcoes.concat(filme.getTitulo()+"\n");
		index = View.solicitarDadosInt("Escolha uma opcao de filme", strOpcoes);
		return tmp = flms.get(index);
	}
	
	public static Cliente selecionaIndexCliente(ArrayList<Cliente> clnts) {
		
	}
	
	public static void validaCodigo(int codigo) {
		if(codigo < 0)
			throw new IllegalArgumentException("Codigo de filme invalido!");
	}
	
	public static void validaString(String str) {
		if(str.isEmpty())
			throw new IllegalArgumentException("Nome vazio!");
		if(!str.matches("^[a-zA-Z��������������������������]*$"))
			throw new IllegalArgumentException("Nao e permitido inserir numeros nesse campo!");
	}
	
	public static void validaTelefone(String telefone) {
		if(telefone.isEmpty())
			throw new IllegalArgumentException("Numero vazio!");
		if(telefone.length() < 12 || telefone.length() > 12)
			throw new IllegalArgumentException("Numero de telefone invalido!");
		if(!telefone.matches("^[0-9]*$"))
			throw new IllegalArgumentException("Nao e permitido inserir letras nesse campo!");
	}
}
