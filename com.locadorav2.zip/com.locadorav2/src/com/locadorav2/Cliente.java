package com.locadorav2;

public class Cliente {
	//ATTRIBUTES
	private int codigo;
	private String nome;
	private String telefone;
	//CONSTRUCTOR
	public Cliente(int codigo, String nome, String telefone) {
		setCodigo(codigo);
		setNome(nome);
		setTelefone(telefone);
	}
	//METHODS
	//GETTERS & SETTERS
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		Utils.validaCodigo(codigo);
		this.codigo = codigo;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		Utils.validaString(nome);
		this.nome = nome;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		Utils.validaTelefone(telefone);
		this.telefone = telefone;
	}
}
