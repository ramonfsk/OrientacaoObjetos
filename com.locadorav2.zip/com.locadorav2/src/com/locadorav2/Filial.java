package com.locadorav2;

import java.util.ArrayList;

public class Filial {
	//ATTRIBUTES
	private String nome;
	private ArrayList<Locacao> locacoes = new ArrayList<Locacao>();
	//CONSTRUCTOR
	public Filial(String nome) {
		setNome(nome);
	}
	//METHODS
	//GETTERS & SETTERS
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public ArrayList<Locacao> getLocacoes() {
		return locacoes;
	}
}
