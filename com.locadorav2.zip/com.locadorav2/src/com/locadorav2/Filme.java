package com.locadorav2;

public class Filme {
	//ATTRIBUTES
	private int codigo;
	private String titulo;
	private String diretor;
	private boolean estaAlugado;
	//CONSTRUCTOR	
	public Filme(int codigo, String titulo, String diretor) {
		setCodigo(codigo);
		setTitulo(titulo);
		setDiretor(diretor);
		estaAlugado = false;
	}
	//METHODS
	//GETTERS & SETTERS
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		Utils.validaCodigo(codigo);
		this.codigo = codigo;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		Utils.validaString(titulo);
		this.titulo = titulo;
	}
	public String getDiretor() {
		return diretor;
	}
	public void setDiretor(String diretor) {
		Utils.validaString(diretor);
		this.diretor = diretor;
	}
	public boolean getEstaAlugado() {
		return estaAlugado;
	}
	public void setEstaAlugado(boolean estaAlugado) {
		this.estaAlugado = estaAlugado;
	}
}
