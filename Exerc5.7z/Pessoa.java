public class Pessoa {
	//ATRIBUTES
	private String nome;
	private int idade;
	//CONSTRUCTOR
	Pessoa(String nome, int idade){
		setNome(nome);
		setIdade(idade);
	}
	//GET AND SET
	String getNome() {
		return this.nome;
	}
	
	void setNome(String valorNome) {
		this.nome = valorNome;
	}
	
	int getIdade() {
		return this.idade;
	}
	
	void setIdade(int valorIdade) {
		this.idade = valorIdade;
	}
}
