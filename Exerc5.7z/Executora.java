public class Executora {
	public static void main(String[] args) {
		
		Pessoa ramon = new Pessoa("Ramon Ferreira", 25);
		Conta c1 = new Conta(111, 0, ramon);
		Banco sicoob = new Banco("SICOOB");
		
		sicoob.adicionarConta(c1);
		
		for (Conta contas : sicoob.getContas()) {
			System.out.println(contas.getDono().getNome());
		}
		
	}
}
