public class Conta {
	//ATRIBUTES
	private int numero;
	private double limite, saldo;
	private Pessoa dono;
	//CONSTRUCTOR
	Conta(int numero, double limite, Pessoa dono){
		setNumero(numero);
		setLimite(limite);
		setDono(dono);
		setSaldo(0);
	}
	//GET AND SET
	int getNumero() {
		return this.numero;
	}
	
	void setNumero(int numConta) {
		this.numero = numConta;
	}
	
	double getLimite() {
		return this.limite;
	}
	
	void setLimite(double valorLimite) {
		this.limite = valorLimite;
	}
	
	Pessoa getDono() {
		return this.dono;
	}
	
	void setDono(Pessoa dono) {
		this.dono = dono;
	}
	
	double getSaldo() {
		return this.saldo;
	}
	
	void setSaldo(double valorSaldo) {
		this.saldo = valorSaldo;
	}
	
	//METHODS
	boolean sacar(double valorSaque) {
		if(valorSaque < 0) {
			System.out.printf("O valor R$ %.2f e invalido!\n", valorSaque);
			return false;
		}
		if(valorSaque > (this.saldo + this.limite)) {
			System.out.printf("O valor R$ %.2f e superior ao saldo disponivel!\n", (this.saldo + this.limite));
			return false;
			
		}
		setSaldo((valorSaque - this.saldo));
		return true;
		
	}
	
	boolean depositar(double valorDeposito) {
		if(valorDeposito < 0) {
			System.out.printf("Impossivel realizar um deposito com valor negativo!\n");
			return false;
		}
		
		setSaldo(valorDeposito + this.saldo);
		return true;
	}
	
	void transferir(Conta contaDestino, double valorTransferecia) {
		if(this.sacar(valorTransferecia))
			contaDestino.depositar(valorTransferecia);
	}
}
