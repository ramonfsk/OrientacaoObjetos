import java.util.ArrayList;

public class Banco {
	//ATRIBUTES
	private String nome;
	private ArrayList<Conta> contas = new ArrayList<Conta>();
	//CONSTRUCTOR
	Banco(String nome){
		setNome(nome);
	}
	//GET AND SET
	String getNome() {
		return this.nome;
	}
	
	boolean setNome(String valorNome) {
		if(valorNome.isEmpty())
			System.out.printf("O nome nao pode ser vazio!\n");
		this.nome = valorNome;
		return true;
	}
	
	ArrayList<Conta> getContas() {
		return contas;
	}
	//METHODS
	void adicionarConta(Conta conta) {
		contas.add(conta);
	}
	
	void removerConta(Conta conta) {
		contas.remove(conta);
	}
}
