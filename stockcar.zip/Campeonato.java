import java.util.ArrayList;

public class Campeonato {
	//ATRIBUTES
	private String nome;
	private ArrayList<Piloto> pilotos = new ArrayList<Piloto>();
	private ArrayList<Corrida> corridas = new ArrayList<Corrida>();
	//CONSTRUCTOR
	public Campeonato(String nome) {
		setNome(nome);
	}
	//METHODS
	void adicionarPiloto(Piloto piloto) {
		pilotos.add(piloto);
	}
	void removerPiloto(Piloto piloto) {
		pilotos.remove(piloto);
	}
	void adicionarCorrida(Corrida corrida) {
		corridas.add(corrida);
	}
	void removerCorrida(Corrida corrida) {
		corridas.remove(corrida);
	}
	void geraClassificacaoGeral() {
		for(Corrida crd : corridas) {
			crd.geraColocacoesPilotos(pilotos);
		}
	}
	//GETTERS & SETTERS
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public ArrayList<Corrida> getCorridas() {
		return corridas;
	}
}
